<template>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4>Update Employee</h4>
          </div>
          <div class="card-body">
            <form @submit.prevent="update">
              <div class="row">
                <div class="col-12 mb-2">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" class="form-control" v-model="employee.name" :class="{ 'is-invalid': errors.name }">
                    <div class="invalid-feedback" v-if="errors.name">{{ errors.name }}</div>
                  </div>
                </div>
                <div class="col-12 mb-2">
                  <div class="form-group">
                    <label>Job title</label>
                    <input type="text" class="form-control" v-model="employee.job_title" :class="{ 'is-invalid': errors.job_title }">
                    <div class="invalid-feedback" v-if="errors.job_title">{{ errors.job_title }}</div>
                  </div>
                </div>
                <div class="col-12 mb-2">
                  <div class="form-group">
                    <label>Salary</label>
                    <input type="number" class="form-control" v-model="employee.salary" :class="{ 'is-invalid': errors.salary }">
                    <div class="invalid-feedback" v-if="errors.salary">{{ errors.salary }}</div>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </template>

  <script>
  export default {
    name: "update-employee",
    data() {
      return {
        employee: {
          name: "",
          job_title: "",
          salary: "",
          _method: "patch",
        },
        errors: {},
      };
    },
    mounted() {
      this.loadData();
    },
    methods: {
      async loadData() {
        try {
          const response = await this.axios.get(`/api/employee/${this.$route.params.id}`);
          const { name, job_title, salary } = response.data;
          this.employee.name = name;
          this.employee.job_title = job_title;
          this.employee.salary = salary;
        } catch (error) {
          console.log(error);
        }
      },
      async update() {
        // Clear previous errors
        this.errors = {};

        // Validate form fields
        if (!this.employee.name) {
          this.errors.name = "Name is required.";
        }

        if (!this.employee.job_title) {
          this.errors.job_title = "Job title is required.";
        }

        if (!this.employee.salary) {
          this.errors.salary = "Salary is required.";
        } else if (isNaN(this.employee.salary) || this.employee.salary <= 0) {
          this.errors.salary = "Salary must be a positive number.";
        }

        // Submit the form if there are no errors
        if (Object.keys(this.errors).length === 0) {
          try {
            await this.axios.post(`/api/employee/${this.$route.params.id}`, this.employee).then(response=>{
                alert(response.data['message'])
                this.$router.push({name:"employeeList"})
            });
          } catch (error) {
            if (error.response && error.response.data && error.response.data.errors) {
                    // Update the errors object with the server-side validation errors
                this.errors = this.transformErrors(error.response.data.errors);
            } else {
                console.log(error);
            }
          }
        }
      },
      transformErrors(errors) {
            const transformedErrors = {};

            for (const field in errors) {
                transformedErrors[field] = errors[field][0];
            }

            return transformedErrors;
        },
    },
  };
  </script>
