require('./bootstrap');
import { createApp } from 'vue';
import App from './components/App.vue';
import { createRouter, createWebHistory } from 'vue-router';
import axios from 'axios';
import { routes } from './routes';

const router = createRouter({
  history: createWebHistory(),
  routes,
});

const app = createApp(App);

app.use(router);
app.config.globalProperties.axios = axios; // Make axios available globally
app.mount('#app');
