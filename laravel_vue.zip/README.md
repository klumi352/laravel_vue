Please follow this steps to run the project:
1. install composer(PHP dependency manager)
2.install nmp (node package manager)
3.open terminal on the project root folder
4. run "composer update" command this will install all the php dependencies for the laravel application
5.run "npm install" command on terminal
6. run "npm install vue vue-router vue-axios --save"
7.create a new MYSQL database
8. setup database connection on .env file
9. run "php artisan migrate" on terminal to add tables on the database
10. run "npm run watch" to compile vue modules.
11.run "php artisan serve" to run laravel development server.


